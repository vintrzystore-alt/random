export type V3 = [number, number, number];

export const clamp = (v: number, a = 0, b = 1) => Math.min(b, Math.max(a, v));
export const lerp = (a: number, b: number, t: number) => a + (b - a) * t;
/** 0..1 progress of f between a and b */
export const prog = (f: number, a: number, b: number) => clamp((f - a) / (b - a));

export const easeOutCubic = (t: number) => 1 - Math.pow(1 - t, 3);
export const easeInOutCubic = (t: number) =>
  t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2;
export const easeOutBack = (t: number) => {
  const c1 = 1.70158;
  const c3 = c1 + 1;
  return 1 + c3 * Math.pow(t - 1, 3) + c1 * Math.pow(t - 1, 2);
};

/** Deterministic pseudo-random 0..1 (so every render frame is identical). */
export const rand = (seed: number) => {
  const x = Math.sin(seed * 127.1 + 311.7) * 43758.5453;
  return x - Math.floor(x);
};

/**
 * Time-warp for slow motion: between a and b the "content time" advances at `rate`
 * (e.g. 0.2 = 5x slower). Outside the window it runs at normal speed.
 */
export const warp = (f: number, a: number, b: number, rate: number) => {
  if (f <= a) return f;
  if (f <= b) return a + (f - a) * rate;
  return a + (b - a) * rate + (f - b);
};
