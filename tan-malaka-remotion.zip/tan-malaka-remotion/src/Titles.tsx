import React from 'react';
import {AbsoluteFill, spring, useCurrentFrame, useVideoConfig} from 'remotion';
import {DISPLAY_FONT} from './Captions';
import {SAFE, WIDTH} from './config';

type Title = {from: number; to: number; main?: string; sub?: string; color: string; size: number};

const TITLES: Title[] = [
  {from: 3.4, to: 5.0, main: 'MADILOG', sub: 'Materialisme · Dialektika · Logika', color: '#ff3b3b', size: 150},
  {from: 17.7, to: 19.5, main: 'RANTAI PUTUS!', color: '#ffd60a', size: 120},
  {from: 22.3, to: 24.4, main: 'AKSI MASSA', sub: '1926', color: '#ffd60a', size: 140},
  {from: 30.4, to: 34.8, sub: 'Fiksi alternatif sejarah — bukan fakta sejarah', color: '#ffffff', size: 0},
];

export const Titles: React.FC = () => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const t = frame / fps;
  const active = TITLES.find((x) => t >= x.from && t < x.to);
  if (!active) return null;

  const local = frame - Math.round(active.from * fps);
  const pop = spring({frame: local, fps, config: {damping: 9, stiffness: 140}});
  const fadeOut = Math.min(1, (active.to - t) * 6);

  return (
    <AbsoluteFill style={{pointerEvents: 'none'}}>
      <div
        style={{
          position: 'absolute',
          left: SAFE.left,
          width: WIDTH - SAFE.left - SAFE.right,
          top: SAFE.top + 30,
          textAlign: 'center',
          fontFamily: DISPLAY_FONT,
          opacity: fadeOut,
          transform: `scale(${0.3 + 0.7 * pop}) rotate(${-4 * (1 - Math.min(pop, 1))}deg)`,
        }}
      >
        {active.main && (
          <div
            style={{
              fontSize: active.size,
              lineHeight: 1,
              color: active.color,
              WebkitTextStroke: '16px #000',
              paintOrder: 'stroke fill',
              textShadow: '0 12px 0 rgba(0,0,0,0.5)',
            }}
          >
            {active.main}
          </div>
        )}
        {active.sub && (
          <div
            style={{
              marginTop: 14,
              fontSize: active.main ? 46 : 38,
              color: '#fff',
              WebkitTextStroke: '8px #000',
              paintOrder: 'stroke fill',
            }}
          >
            {active.sub}
          </div>
        )}
      </div>
    </AbsoluteFill>
  );
};
