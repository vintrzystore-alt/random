import React from 'react';
import {AbsoluteFill, Audio, Sequence, staticFile, useCurrentFrame} from 'remotion';
import {ThreeCanvas} from '@remotion/three';
import {Lights} from './components/Lights';
import {HookScene} from './scenes/Hook';
import {BodyScene} from './scenes/Body';
import {ClimaxScene} from './scenes/Climax';
import {OutroScene} from './scenes/Outro';
import {Captions} from './Captions';
import {Titles} from './Titles';
import {SafeArea} from './SafeArea';
import {HAS_VOICEOVER, HEIGHT, IMPACTS, SCENES, WIDTH} from './config';

export type GuideMode = 'none' | 'outro' | 'all';
export type MainProps = {guides: GuideMode};

const ImpactFlash: React.FC = () => {
  const frame = useCurrentFrame();
  let o = 0;
  for (const i of IMPACTS) {
    const d = frame - i.f;
    if (d >= 0 && d < 7) o = Math.max(o, i.amp * (1 - d / 7));
  }
  return o > 0 ? <AbsoluteFill style={{background: '#fff', opacity: o, pointerEvents: 'none'}} /> : null;
};

export const TanMalaka: React.FC<MainProps> = ({guides}) => {
  const frame = useCurrentFrame();
  const inOutro = frame >= SCENES.outro.from;
  const showGuides = guides === 'all' || (guides === 'outro' && inOutro);

  return (
    <AbsoluteFill style={{backgroundColor: '#000'}}>
      <ThreeCanvas
        width={WIDTH}
        height={HEIGHT}
        shadows
        flat
        camera={{fov: 50, position: [0, 3, 10], near: 0.1, far: 200}}
      >
        <Lights />
        <Sequence from={SCENES.hook.from} durationInFrames={SCENES.hook.duration} layout="none">
          <HookScene />
        </Sequence>
        <Sequence from={SCENES.body.from} durationInFrames={SCENES.body.duration} layout="none">
          <BodyScene />
        </Sequence>
        <Sequence from={SCENES.climax.from} durationInFrames={SCENES.climax.duration} layout="none">
          <ClimaxScene />
        </Sequence>
        <Sequence from={SCENES.outro.from} durationInFrames={SCENES.outro.duration} layout="none">
          <OutroScene />
        </Sequence>
      </ThreeCanvas>

      <ImpactFlash />
      <Titles />
      <Captions />
      {showGuides && <SafeArea />}
      {HAS_VOICEOVER && <Audio src={staticFile('voiceover.mp3')} />}
    </AbsoluteFill>
  );
};
