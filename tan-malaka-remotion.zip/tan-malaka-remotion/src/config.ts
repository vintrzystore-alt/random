export const FPS = 30;
export const WIDTH = 1080;
export const HEIGHT = 1920;
export const DURATION_FRAMES = 35 * FPS; // 1050 frames
export const sec = (s: number) => Math.round(s * FPS);

/** Put your voiceover at public/voiceover.mp3, then set this to true. */
export const HAS_VOICEOVER = false;

export const SCENES = {
  hook: {from: sec(0), duration: sec(5)},
  body: {from: sec(5), duration: sec(15)},
  climax: {from: sec(20), duration: sec(10)},
  outro: {from: sec(30), duration: sec(5)},
} as const;

/**
 * Conservative social-media safe area in px (1080x1920).
 * TikTok/IG/Reels UI shifts between app versions, so re-check against the
 * platforms' current templates before publishing.
 */
export const SAFE = {top: 250, bottom: 480, left: 60, right: 170} as const;

/** Body scene slow-motion window (local frames) + the chain-break moment (warped time). */
export const BODY = {slowFrom: 330, slowTo: 420, slowRate: 0.2, breakT: 340} as const;
/** Local frame at which the chains actually snap (inside the slow-mo window). */
export const BODY_BREAK_FRAME = BODY.slowFrom + (BODY.breakT - BODY.slowFrom) / BODY.slowRate; // 380

export const HOOK_IMPACT = 32; // local frame of the first stomp
export const CLIMAX_SLAM = 70; // local frame the book hits the ground

/** Global frames that get a white impact-flash. */
export const IMPACTS = [
  {f: SCENES.hook.from + HOOK_IMPACT, amp: 0.5},
  {f: SCENES.body.from + BODY_BREAK_FRAME, amp: 0.9},
  {f: SCENES.climax.from + CLIMAX_SLAM, amp: 1},
];
