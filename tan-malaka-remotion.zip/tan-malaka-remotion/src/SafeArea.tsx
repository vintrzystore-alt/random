import React from 'react';
import {AbsoluteFill, useVideoConfig} from 'remotion';
import {SAFE} from './config';

const tint = 'rgba(255, 0, 60, 0.28)';

/** Debug overlay: red = UI-danger zone, green dashed box = safe zone. */
export const SafeArea: React.FC = () => {
  const {width, height} = useVideoConfig();
  const midH = height - SAFE.top - SAFE.bottom;
  const icon = (y: number, size = 84) => (
    <div
      style={{
        position: 'absolute',
        right: 40,
        top: y,
        width: size,
        height: size,
        borderRadius: '50%',
        background: 'rgba(255,255,255,0.55)',
        border: '3px solid #fff',
      }}
    />
  );
  return (
    <AbsoluteFill style={{pointerEvents: 'none', fontFamily: 'Arial, sans-serif'}}>
      <div style={{position: 'absolute', left: 0, top: 0, width, height: SAFE.top, background: tint}} />
      <div style={{position: 'absolute', left: 0, bottom: 0, width, height: SAFE.bottom, background: tint}} />
      <div style={{position: 'absolute', left: 0, top: SAFE.top, width: SAFE.left, height: midH, background: tint}} />
      <div style={{position: 'absolute', right: 0, top: SAFE.top, width: SAFE.right, height: midH, background: tint}} />

      <div
        style={{
          position: 'absolute',
          left: SAFE.left,
          top: SAFE.top,
          width: width - SAFE.left - SAFE.right,
          height: midH,
          border: '4px dashed #00ff9d',
          boxSizing: 'border-box',
        }}
      />
      <div style={{position: 'absolute', left: SAFE.left + 12, top: SAFE.top + 8, color: '#00ff9d', fontSize: 30, fontWeight: 700}}>
        SAFE ZONE
      </div>

      {/* mock platform UI */}
      {icon(820)}
      {icon(950)}
      {icon(1080)}
      {icon(1210)}
      {icon(1340, 70)}
      <div style={{position: 'absolute', left: 50, bottom: 300, width: 520, height: 34, borderRadius: 17, background: 'rgba(255,255,255,0.55)'}} />
      <div style={{position: 'absolute', left: 50, bottom: 240, width: 760, height: 26, borderRadius: 13, background: 'rgba(255,255,255,0.4)'}} />
      <div style={{position: 'absolute', left: 50, bottom: 190, width: 640, height: 26, borderRadius: 13, background: 'rgba(255,255,255,0.4)'}} />
      <div style={{position: 'absolute', left: 0, right: 0, top: 70, textAlign: 'center', color: '#fff', fontSize: 34, fontWeight: 700}}>
        TOP UI (search / following / live)
      </div>
    </AbsoluteFill>
  );
};
