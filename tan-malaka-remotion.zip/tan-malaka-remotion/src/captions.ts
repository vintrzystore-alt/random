/**
 * Indonesian voiceover script + timings (seconds, global timeline).
 * Words are spread across [start, end] by character length unless you provide
 * exact `words` timings (e.g. from Whisper) for a line.
 */
export type WordTiming = {text: string; start: number; end: number};
export type CaptionLine = {text: string; start: number; end: number; words?: WordTiming[]};

export const CAPTIONS: CaptionLine[] = [
  // HOOK 0-5s
  {text: 'Bagaimana jika Indonesia dipimpin oleh Tan Malaka?', start: 0.3, end: 3.2},
  {text: 'Satu langkah, dan peta mulai berubah.', start: 3.3, end: 4.95},
  // BODY 5-20s
  {text: 'Tanpa takhayul, semua keputusan lewat Madilog: materialisme, dialektika, logika.', start: 5.2, end: 9.6},
  {text: 'Pabrik dan sawah dibangun untuk rakyat, bukan segelintir orang.', start: 9.8, end: 14.0},
  {text: 'Buruh dan petani bersatu, memutus rantai yang membelenggu mereka.', start: 14.2, end: 19.6},
  // CLIMAX 20-30s
  {text: 'Lalu Aksi Massa menghantam, membangunkan sebuah bangsa.', start: 20.2, end: 24.0},
  {text: 'Dari kekuatan rakyat, lahirlah kota masa depan ala 1950-an.', start: 24.2, end: 29.6},
  // OUTRO 30-35s
  {text: 'Hanya imajinasi. Menurutmu, akan jadi seperti apa Indonesia?', start: 30.3, end: 34.6},
];
