import {useLayoutEffect} from 'react';
import {useThree} from '@react-three/fiber';
import {useCurrentFrame} from 'remotion';
import * as THREE from 'three';
import {clamp, V3} from '../util';

export type CamKey = {f: number; pos: V3; look: V3};
export type Shake = {f: number; amp: number; dur?: number};

// Catmull-Rom: smooth path through the keyframes (no stop-start at each key)
const cr = (p0: number, p1: number, p2: number, p3: number, t: number) =>
  0.5 *
  (2 * p1 +
    (-p0 + p2) * t +
    (2 * p0 - 5 * p1 + 4 * p2 - p3) * t * t +
    (-p0 + 3 * p1 - 3 * p2 + p3) * t * t * t);

const sample = (keys: CamKey[], frame: number, pick: (k: CamKey) => V3): V3 => {
  let i = keys.length - 2;
  for (let j = 0; j < keys.length - 1; j++) {
    if (frame < keys[j + 1].f) {
      i = j;
      break;
    }
  }
  i = Math.max(0, i);
  const k0 = keys[Math.max(0, i - 1)];
  const k1 = keys[i];
  const k2 = keys[i + 1];
  const k3 = keys[Math.min(keys.length - 1, i + 2)];
  const t = clamp((frame - k1.f) / (k2.f - k1.f));
  const a = pick(k0), b = pick(k1), c = pick(k2), d = pick(k3);
  return [0, 1, 2].map((n) => cr(a[n], b[n], c[n], d[n], t)) as V3;
};

/** Drives the R3F camera from keyframes (local frames of the surrounding <Sequence>). */
export const SceneCamera: React.FC<{keys: CamKey[]; shakes?: Shake[]; fov?: number}> = ({
  keys,
  shakes = [],
  fov = 50,
}) => {
  const frame = useCurrentFrame();
  const camera = useThree((s) => s.camera) as THREE.PerspectiveCamera;

  useLayoutEffect(() => {
    const p = sample(keys, frame, (k) => k.pos);
    const l = sample(keys, frame, (k) => k.look);
    let sx = 0;
    let sy = 0;
    for (const s of shakes) {
      const dur = s.dur ?? 18;
      const d = frame - s.f;
      if (d >= 0 && d < dur) {
        const k = Math.pow(1 - d / dur, 2);
        sx += Math.sin(frame * 12.9898) * s.amp * k;
        sy += Math.cos(frame * 78.233) * s.amp * k;
      }
    }
    camera.position.set(p[0] + sx, p[1] + sy, p[2]);
    camera.fov = fov;
    camera.updateProjectionMatrix();
    camera.lookAt(l[0], l[1], l[2]);
  });

  return null;
};
