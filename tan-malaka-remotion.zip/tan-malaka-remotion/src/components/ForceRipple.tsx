import React from 'react';
import * as THREE from 'three';
import {V3} from '../util';

/** Flat expanding shockwave rings on the ground. radius is in world units. */
export const ForceRipple: React.FC<{
  position: V3;
  radius: number;
  opacity?: number;
  color?: string;
}> = ({position, radius, opacity = 1, color = '#ff2a2a'}) => {
  if (radius <= 0.01 || opacity <= 0) return null;
  const rings = [1, 0.84, 0.68];
  return (
    <group position={position} rotation={[-Math.PI / 2, 0, 0]}>
      {rings.map((k, i) => (
        <mesh key={i} scale={[radius * k, radius * k, 1]}>
          <ringGeometry args={[0.93, 1, 96]} />
          <meshBasicMaterial
            color={color}
            transparent
            opacity={opacity * (1 - i * 0.28)}
            side={THREE.DoubleSide}
            depthWrite={false}
            toneMapped={false}
          />
        </mesh>
      ))}
    </group>
  );
};
