import React from 'react';

export const Lights: React.FC = () => (
  <>
    <ambientLight intensity={0.9} />
    <directionalLight
      position={[8, 14, 9]}
      intensity={1.7}
      castShadow
      shadow-mapSize={[2048, 2048]}
      shadow-camera-left={-18}
      shadow-camera-right={18}
      shadow-camera-top={18}
      shadow-camera-bottom={-18}
      shadow-camera-near={1}
      shadow-camera-far={60}
    />
    <directionalLight position={[-8, 6, -6]} intensity={0.6} color="#a8c8ff" />
  </>
);
