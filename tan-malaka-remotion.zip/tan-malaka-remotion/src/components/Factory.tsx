import React from 'react';
import {easeOutBack, prog, V3} from '../util';

/** Giant factory that erupts from the ground. t = warped scene time (frames). */
export const Factory: React.FC<{t: number; position: V3}> = ({t, position}) => {
  const rise = easeOutBack(prog(t, 20, 110));
  const done = prog(t, 90, 110);
  return (
    <group position={[position[0], position[1] - 7 * (1 - rise), position[2]]}>
      <mesh position={[0, 1.1, 0]} castShadow receiveShadow>
        <boxGeometry args={[4.4, 2.2, 2.4]} />
        <meshStandardMaterial color="#b8b2a7" />
      </mesh>
      {[-1.4, 0, 1.4].map((x, i) => (
        <mesh key={i} position={[x, 2.45, 0]} rotation={[0, 0, 0.45]} castShadow>
          <boxGeometry args={[1.5, 0.14, 2.4]} />
          <meshStandardMaterial color="#8d3b2f" />
        </mesh>
      ))}
      {/* windows */}
      {[-1.6, -0.8, 0, 0.8, 1.6].map((x, i) => (
        <mesh key={i} position={[x, 1.2, 1.21]}>
          <boxGeometry args={[0.4, 0.5, 0.02]} />
          <meshStandardMaterial color="#ffe08a" emissive="#ffcc33" emissiveIntensity={0.7} />
        </mesh>
      ))}
      {/* chimneys + smoke */}
      {[-1.5, -0.6].map((x, ci) => (
        <group key={ci} position={[x, 0, -0.5]}>
          <mesh position={[0, 3.1, 0]} castShadow>
            <cylinderGeometry args={[0.3, 0.38, 2.9, 14]} />
            <meshStandardMaterial color="#b5543c" />
          </mesh>
          <mesh position={[0, 4.58, 0]}>
            <cylinderGeometry args={[0.34, 0.3, 0.2, 14]} />
            <meshStandardMaterial color="#2b2b2b" />
          </mesh>
          {done > 0.5 &&
            [0, 1, 2, 3, 4].map((k) => {
              const ph = (t * 0.012 + k / 5 + ci * 0.37) % 1;
              return (
                <mesh key={k} position={[ph * 0.8, 4.8 + ph * 3.2, 0]} scale={0.3 + ph * 0.7}>
                  <sphereGeometry args={[0.5, 12, 12]} />
                  <meshStandardMaterial color="#f2f2f2" transparent opacity={0.9 * (1 - ph)} />
                </mesh>
              );
            })}
        </group>
      ))}
      {/* spinning gear emblem */}
      <mesh position={[1.4, 3.1, 0.2]} rotation={[Math.PI / 2, t * 0.04, 0]} castShadow>
        <cylinderGeometry args={[0.7, 0.7, 0.3, 8]} />
        <meshStandardMaterial color="#d7263d" />
      </mesh>
    </group>
  );
};
