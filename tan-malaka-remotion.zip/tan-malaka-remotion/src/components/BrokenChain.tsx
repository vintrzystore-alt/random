import React from 'react';
import {easeInOutCubic, prog, rand, V3} from '../util';

/**
 * A ring of chain links. Tightens + vibrates before breakT, then every link flies
 * off with its own velocity/spin under cartoon gravity. t = warped time (frames).
 */
export const BrokenChain: React.FC<{t: number; breakT: number; center: V3; radius: number; n?: number}> = ({
  t,
  breakT,
  center,
  radius,
  n = 16,
}) => {
  const pre = prog(t, breakT - 45, breakT);
  const tight = 1 - 0.18 * easeInOutCubic(pre);
  const broken = t >= breakT;
  const dt = Math.max(0, t - breakT) / 30;

  return (
    <group>
      {Array.from({length: n}).map((_, i) => {
        const a = (i / n) * Math.PI * 2;
        const r = radius * tight + (broken ? 0 : Math.sin(t * 0.9 + i) * 0.03 * pre);
        let x = center[0] + Math.cos(a) * r;
        let y = center[1];
        let z = center[2] + Math.sin(a) * r;
        let spinX = 0;
        let spinZ = 0;
        if (broken) {
          const vr = 4 + rand(i + 3) * 4;
          const vy = 6 + rand(i + 17) * 5;
          x += Math.cos(a) * vr * dt;
          z += Math.sin(a) * vr * dt;
          y = Math.max(0.1, center[1] + vy * dt - 0.5 * 16 * dt * dt);
          const flying = y > 0.11;
          spinX = flying ? (rand(i + 31) - 0.5) * 14 * dt : 0;
          spinZ = flying ? (rand(i + 47) - 0.5) * 14 * dt : 0;
        }
        return (
          <group key={i} position={[x, y, z]} rotation={[0, -(a + Math.PI / 2), 0]}>
            <group rotation={[(i % 2 ? Math.PI / 2 : 0) + spinX, 0, spinZ]}>
              <mesh scale={[1.35, 1, 1]} castShadow>
                <torusGeometry args={[0.2, 0.055, 8, 18]} />
                <meshStandardMaterial color="#b8bcc6" metalness={0.3} roughness={0.35} />
              </mesh>
            </group>
          </group>
        );
      })}
    </group>
  );
};
