import React from 'react';
import {easeOutBack, prog, V3} from '../util';

/** Agrarian rows that sprout from the ground. t = warped scene time (frames). */
export const Fields: React.FC<{t: number; position: V3; width?: number; rows?: number}> = ({
  t,
  position,
  width = 2.2,
  rows = 5,
}) => (
  <group position={position}>
    {Array.from({length: rows}).map((_, r) => {
      const e = easeOutBack(prog(t, 60 + r * 14, 96 + r * 14));
      const count = Math.round(width / 0.28);
      return (
        <group key={r} position={[0, 0, -r * 0.65]} scale={[1, Math.max(e, 0.001), 1]}>
          <mesh position={[0, 0.1, 0]} receiveShadow>
            <boxGeometry args={[width, 0.2, 0.5]} />
            <meshStandardMaterial color="#6b4423" />
          </mesh>
          {Array.from({length: count}).map((__, i) => {
            const x = -width / 2 + (i + 0.5) * (width / count);
            return (
              <mesh
                key={i}
                position={[x, 0.45, 0]}
                rotation={[0, 0, Math.sin(t * 0.07 + i * 0.8 + r) * 0.12]}
                castShadow
              >
                <coneGeometry args={[0.11, 0.5, 6]} />
                <meshStandardMaterial color="#ffd23f" />
              </mesh>
            );
          })}
        </group>
      );
    })}
  </group>
);
