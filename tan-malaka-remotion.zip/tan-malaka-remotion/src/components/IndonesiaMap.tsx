import React from 'react';
import * as THREE from 'three';
import {clamp, easeOutCubic} from '../util';

/** Crude archipelago proxy. x = north(+)/south(-), z = west(+)/east(-). Replace with a GLTF map later. */
type Island = {c: [number, number]; s: [number, number]; r: number};
export const ISLANDS: Island[] = [
  {c: [-0.1, 5.9], s: [0.85, 3.0], r: Math.PI / 4}, // Sumatra
  {c: [-3.0, 2.95], s: [0.42, 1.65], r: 0}, // Java
  {c: [0.2, 1.4], s: [2.0, 1.7], r: 0}, // Kalimantan
  {c: [0.3, -0.4], s: [0.35, 0.7], r: -0.5}, // Sulawesi
  {c: [-0.7, -0.9], s: [0.35, 0.9], r: 0.2},
  {c: [-1.5, -0.5], s: [0.3, 0.6], r: 0},
  {c: [-2.0, -6.3], s: [1.6, 2.0], r: 0.4}, // Papua
  {c: [-1.3, -3.6], s: [0.5, 0.6], r: 0}, // Maluku
  {c: [0.4, -3.0], s: [0.35, 0.5], r: 0},
  {c: [-3.7, 0.9], s: [0.25, 0.35], r: 0}, // Bali
  {c: [-3.9, 0.1], s: [0.3, 0.6], r: 0}, // Nusa Tenggara
  {c: [-4.0, -1.2], s: [0.25, 1.0], r: 0},
  {c: [-4.6, -2.4], s: [0.25, 0.8], r: 0.4},
];

const BASE = new THREE.Color('#e3c98f');
const RED = new THREE.Color('#d7263d');

/**
 * The map "converts" to red as the force ripple (radius, centred on origin [x,z])
 * passes each island; islands also pop up while the wave crosses them.
 */
export const IndonesiaMap: React.FC<{origin: [number, number]; radius: number}> = ({origin, radius}) => (
  <group>
    <mesh position={[0, -0.08, 0]} rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
      <planeGeometry args={[80, 80]} />
      <meshStandardMaterial color="#2a9fd6" roughness={0.4} />
    </mesh>
    {ISLANDS.map((il, i) => {
      const d = Math.hypot(il.c[0] - origin[0], il.c[1] - origin[1]) - Math.max(il.s[0], il.s[1]) * 0.5;
      const k = easeOutCubic(clamp((radius - d) / 2.5));
      const color = BASE.clone().lerp(RED, k);
      const h = 0.3 + 0.25 * Math.sin(k * Math.PI);
      return (
        <mesh
          key={i}
          position={[il.c[0], h / 2, il.c[1]]}
          rotation={[0, il.r, 0]}
          scale={[il.s[0], h, il.s[1]]}
          castShadow
          receiveShadow
        >
          <cylinderGeometry args={[1, 1.06, 1, 40]} />
          <meshStandardMaterial color={color} emissive={RED} emissiveIntensity={k * 0.25} roughness={0.7} />
        </mesh>
      );
    })}
  </group>
);
