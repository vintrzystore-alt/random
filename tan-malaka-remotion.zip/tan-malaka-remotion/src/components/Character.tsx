import React from 'react';
import {V3} from '../util';

type Hat = 'pith' | 'hardhat' | 'caping' | 'none';

export type CharacterProps = {
  position?: V3;
  rotationY?: number;
  scale?: number;
  /** walk-cycle phase in radians (0 = idle) */
  walk?: number;
  /** 1 = normal, <1 = squashed (volume is preserved by widening) */
  squash?: number;
  /** 0..1 – both arms raised (victory fists) */
  armsUp?: number;
  coat?: string;
  skin?: string;
  hat?: Hat;
  hatColor?: string;
  glasses?: boolean;
};

const Mat: React.FC<{c: string}> = ({c}) => <meshStandardMaterial color={c} roughness={0.65} />;

/**
 * PLACEHOLDER cartoon character built from primitives.
 * Front of the character faces +Z. Swap this whole component for a GLTF later.
 */
export const Character: React.FC<CharacterProps> = ({
  position = [0, 0, 0],
  rotationY = 0,
  scale = 1,
  walk = 0,
  squash = 1,
  armsUp = 0,
  coat = '#c9b28a',
  skin = '#c98f63',
  hat = 'pith',
  hatColor = '#efe3c2',
  glasses = true,
}) => {
  const swing = Math.sin(walk) * 0.65;
  const wide = 1 / Math.sqrt(Math.max(squash, 0.2));
  const armAngle = 0.15 + armsUp * 2.7;

  return (
    <group position={position} rotation={[0, rotationY, 0]} scale={[scale * wide, scale * squash, scale * wide]}>
      {/* legs */}
      {[-1, 1].map((side) => (
        <group key={side} position={[side * 0.2, 0.95, 0]} rotation={[side * swing, 0, 0]}>
          <mesh position={[0, -0.42, 0]} castShadow>
            <capsuleGeometry args={[0.14, 0.55, 6, 12]} />
            <Mat c="#3b3029" />
          </mesh>
          <mesh position={[0, -0.84, 0.08]} castShadow>
            <boxGeometry args={[0.3, 0.14, 0.44]} />
            <Mat c="#1e1a17" />
          </mesh>
        </group>
      ))}

      {/* trench coat */}
      <mesh position={[0, 1.55, 0]} castShadow>
        <cylinderGeometry args={[0.45, 0.65, 1.25, 20]} />
        <Mat c={coat} />
      </mesh>
      <mesh position={[0, 1.5, 0]} rotation={[Math.PI / 2, 0, 0]}>
        <torusGeometry args={[0.57, 0.05, 8, 24]} />
        <Mat c="#6b4f2a" />
      </mesh>
      <mesh position={[0, 2.18, 0]} rotation={[Math.PI / 2, 0, 0]}>
        <torusGeometry args={[0.4, 0.13, 8, 20]} />
        <Mat c={coat} />
      </mesh>

      {/* arms */}
      {[-1, 1].map((side) => (
        <group
          key={side}
          position={[side * 0.55, 2.05, 0]}
          rotation={[-side * swing * 0.8, 0, side * armAngle]}
        >
          <mesh position={[0, -0.4, 0]} castShadow>
            <capsuleGeometry args={[0.11, 0.55, 6, 12]} />
            <Mat c={coat} />
          </mesh>
          <mesh position={[0, -0.84, 0]} castShadow>
            <sphereGeometry args={[0.14, 12, 12]} />
            <Mat c={skin} />
          </mesh>
        </group>
      ))}

      {/* head (oversized = cartoon) */}
      <mesh position={[0, 2.75, 0]} castShadow>
        <sphereGeometry args={[0.55, 24, 24]} />
        <Mat c={skin} />
      </mesh>
      <mesh position={[0, 2.68, 0.52]}>
        <sphereGeometry args={[0.07, 10, 10]} />
        <Mat c="#a9714a" />
      </mesh>
      {[-1, 1].map((side) => (
        <group key={side}>
          <mesh position={[side * 0.2, 2.8, 0.49]}>
            <sphereGeometry args={[0.055, 10, 10]} />
            <meshStandardMaterial color="#111" />
          </mesh>
          {glasses && (
            <mesh position={[side * 0.2, 2.8, 0.5]}>
              <torusGeometry args={[0.15, 0.025, 8, 20]} />
              <meshStandardMaterial color="#111" />
            </mesh>
          )}
        </group>
      ))}
      {glasses && (
        <mesh position={[0, 2.8, 0.52]}>
          <boxGeometry args={[0.12, 0.02, 0.02]} />
          <meshStandardMaterial color="#111" />
        </mesh>
      )}

      {/* hats */}
      {hat === 'pith' && (
        <group position={[0, 2.93, 0]}>
          <mesh castShadow>
            <sphereGeometry args={[0.62, 24, 14, 0, Math.PI * 2, 0, Math.PI / 2]} />
            <Mat c={hatColor} />
          </mesh>
          <mesh position={[0, -0.02, 0]}>
            <cylinderGeometry args={[0.86, 0.86, 0.07, 28]} />
            <Mat c={hatColor} />
          </mesh>
          <mesh position={[0, 0.06, 0]} rotation={[Math.PI / 2, 0, 0]}>
            <torusGeometry args={[0.6, 0.04, 8, 28]} />
            <Mat c="#6b4f2a" />
          </mesh>
        </group>
      )}
      {hat === 'hardhat' && (
        <group position={[0, 2.93, 0]}>
          <mesh castShadow>
            <sphereGeometry args={[0.6, 20, 12, 0, Math.PI * 2, 0, Math.PI / 2]} />
            <Mat c="#ffd23f" />
          </mesh>
          <mesh position={[0, -0.01, 0.35]}>
            <boxGeometry args={[0.9, 0.06, 0.6]} />
            <Mat c="#ffd23f" />
          </mesh>
        </group>
      )}
      {hat === 'caping' && (
        <mesh position={[0, 3.2, 0]} castShadow>
          <coneGeometry args={[0.98, 0.55, 24]} />
          <Mat c="#d9b26f" />
        </mesh>
      )}
    </group>
  );
};
