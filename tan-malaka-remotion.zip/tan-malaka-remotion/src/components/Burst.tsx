import React from 'react';
import {rand, V3} from '../util';

/** Debris / dust / sparks. t = frames since the impact. Pure function of t (deterministic). */
export const Burst: React.FC<{
  t: number;
  position: V3;
  count?: number;
  speed?: number;
  color?: string;
  size?: number;
  life?: number;
}> = ({t, position, count = 18, speed = 5, color = '#d9c7a0', size = 0.12, life = 40}) => {
  if (t < 0 || t > life) return null;
  const s = t / 30;
  const k = 1 - t / life;
  return (
    <group position={position}>
      {Array.from({length: count}).map((_, i) => {
        const a = rand(i + 1) * Math.PI * 2;
        const v = speed * (0.5 + rand(i + 50));
        const up = speed * (0.6 + rand(i + 90) * 0.9);
        const x = Math.cos(a) * v * s;
        const z = Math.sin(a) * v * s;
        const y = Math.max(0, up * s - 9 * s * s);
        return (
          <mesh key={i} position={[x, y, z]} scale={size * (0.5 + rand(i + 9)) * k * 3}>
            <icosahedronGeometry args={[1, 0]} />
            <meshStandardMaterial color={color} flatShading />
          </mesh>
        );
      })}
    </group>
  );
};
