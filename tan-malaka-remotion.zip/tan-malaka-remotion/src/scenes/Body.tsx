import React from 'react';
import {useCurrentFrame} from 'remotion';
import {Character} from '../components/Character';
import {Factory} from '../components/Factory';
import {Fields} from '../components/Fields';
import {BrokenChain} from '../components/BrokenChain';
import {ForceRipple} from '../components/ForceRipple';
import {Burst} from '../components/Burst';
import {CamKey, SceneCamera} from '../components/SceneCamera';
import {BODY, BODY_BREAK_FRAME} from '../config';
import {easeInOutCubic, lerp, prog, warp, V3} from '../util';

const KEYS: CamKey[] = [
  {f: 0, pos: [0, 2.2, 12], look: [0, 2, -3]},
  {f: 150, pos: [-4, 3.5, 10], look: [0, 1, 0]},
  {f: 300, pos: [0, 2.6, 8.5], look: [0, 1.3, 1.5]},
  {f: BODY_BREAK_FRAME, pos: [0, 1.8, 5.2], look: [0, 1.5, 2]}, // push-in during slow-mo
  {f: 450, pos: [0, 5, 12], look: [0, 1, 0]},
];

const CENTER: V3 = [0, 1.1, 2.4];

const workers = [
  {sx: -3.4, ex: -0.9, z: 1.6, delay: 0},
  {sx: -4.2, ex: -0.6, z: 2.5, delay: 8},
  {sx: -3.8, ex: -1.1, z: 3.3, delay: 16},
];
const farmers = workers.map((w) => ({sx: -w.sx, ex: -w.ex, z: w.z + 0.2, delay: w.delay + 4}));

export const BodyScene: React.FC = () => {
  const f = useCurrentFrame();
  // warped "content time": slow-mo window around the chain break
  const t = warp(f, BODY.slowFrom, BODY.slowTo, BODY.slowRate);
  const after = t - BODY.breakT;

  const renderCrowd = (list: typeof workers, side: 1 | -1, farmer: boolean) =>
    list.map((p, i) => {
      const run = prog(t, 150 + p.delay, 290);
      const x = lerp(p.sx, p.ex, easeInOutCubic(run));
      const moving = run > 0 && run < 1;
      const faceCam = easeInOutCubic(prog(t, 270, 300));
      const hop = after > 0 ? Math.abs(Math.sin(after * 0.18 + i)) * 0.5 : 0;
      return (
        <Character
          key={`${farmer ? 'f' : 'w'}${i}`}
          position={[x, hop, p.z]}
          rotationY={lerp((side * Math.PI) / 2, 0, faceCam)}
          scale={0.6}
          walk={moving ? t * 0.5 : 0}
          armsUp={prog(t, 290, 325)}
          coat={farmer ? '#4f8a3a' : '#ff8c42'}
          hat={farmer ? 'caping' : 'hardhat'}
          glasses={false}
          skin={farmer ? '#b9794e' : '#c98f63'}
        />
      );
    });

  return (
    <>
      <color attach="background" args={['#bfe6ff']} />
      <fog attach="fog" args={['#bfe6ff', 25, 80]} />
      <SceneCamera keys={KEYS} shakes={[{f: BODY_BREAK_FRAME, amp: 0.35, dur: 30}]} />

      {/* ground + road + stage */}
      <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
        <planeGeometry args={[80, 80]} />
        <meshStandardMaterial color="#8ab356" />
      </mesh>
      <mesh position={[0, 0.02, -2]} rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
        <planeGeometry args={[2, 24]} />
        <meshStandardMaterial color="#555a63" />
      </mesh>
      <mesh position={[0, 0.03, 2.4]} rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
        <circleGeometry args={[2.3, 40]} />
        <meshStandardMaterial color="#d9c7a0" />
      </mesh>

      <Factory t={t} position={[0, 0, -6.2]} />
      <Fields t={t} position={[-2.4, 0, -0.7]} />
      <Fields t={t} position={[2.4, 0, -0.7]} />

      {renderCrowd(workers, 1, false)}
      {renderCrowd(farmers, -1, true)}

      <BrokenChain t={t} breakT={BODY.breakT} center={CENTER} radius={1.5} />

      <ForceRipple
        position={[CENTER[0], 0.06, CENTER[2]]}
        radius={7 * Math.max(0, prog(t, BODY.breakT, BODY.breakT + 14))}
        opacity={1 - prog(t, BODY.breakT + 6, BODY.breakT + 16)}
        color="#ffd23f"
      />
      <Burst t={after} position={[CENTER[0], 1.1, CENTER[2]]} count={26} speed={5} color="#ffd23f" life={30} />
      <pointLight
        position={[CENTER[0], 2, CENTER[2]]}
        color="#fff2b0"
        intensity={after >= 0 ? 150 * (1 - prog(t, BODY.breakT, BODY.breakT + 10)) : 0}
        distance={14}
      />
    </>
  );
};
