import React, {useMemo} from 'react';
import {useCurrentFrame} from 'remotion';
import {Character} from '../components/Character';
import {CamKey, SceneCamera} from '../components/SceneCamera';
import {rand} from '../util';

const KEYS: CamKey[] = [
  {f: 0, pos: [4.5, 3.2, 7], look: [0, 2.8, -2]},
  {f: 90, pos: [3.2, 3.1, 4.6], look: [-0.2, 2.85, -3]},
  {f: 150, pos: [2.2, 3.0, 2.6], look: [-0.4, 2.9, -4]}, // slow zoom toward his face
];

export const OutroScene: React.FC = () => {
  const f = useCurrentFrame();

  const skyline = useMemo(
    () =>
      Array.from({length: 22}).map((_, i) => ({
        x: -16 + i * 1.5 + rand(i) * 0.6,
        h: 1.5 + rand(i + 40) * 4,
        w: 0.9 + rand(i + 80) * 0.8,
      })),
    [],
  );

  return (
    <>
      <color attach="background" args={['#ff9966']} />
      <fog attach="fog" args={['#ff9966', 25, 90]} />
      <hemisphereLight args={['#ffd0a0', '#40305a', 0.7]} />
      <directionalLight position={[-3, 3, -10]} color="#ffb36b" intensity={2.2} />
      <directionalLight position={[4, 3, 8]} color="#ffe3c2" intensity={0.8} />
      <SceneCamera keys={KEYS} />

      {/* sun on the horizon */}
      <mesh position={[0, 3.5, -45]}>
        <circleGeometry args={[8, 48]} />
        <meshBasicMaterial color="#ff6b35" toneMapped={false} />
      </mesh>
      <mesh position={[0, 3.5, -45.1]}>
        <circleGeometry args={[13, 48]} />
        <meshBasicMaterial color="#ffc08a" transparent opacity={0.4} toneMapped={false} />
      </mesh>

      {/* distant retro-futuristic skyline (callback to the climax) */}
      {skyline.map((b, i) => (
        <mesh key={i} position={[b.x, b.h / 2 - 1.2, -32]}>
          <boxGeometry args={[b.w, b.h, b.w]} />
          <meshStandardMaterial color="#3a2a4d" />
        </mesh>
      ))}
      <mesh position={[0, 4, -32]}>
        <cylinderGeometry args={[0.1, 0.4, 10, 4]} />
        <meshStandardMaterial color="#3a2a4d" />
      </mesh>

      {/* ground + hill */}
      <mesh position={[0, -1.2, 0]} rotation={[-Math.PI / 2, 0, 0]}>
        <circleGeometry args={[60, 48]} />
        <meshStandardMaterial color="#2f4858" />
      </mesh>
      <mesh position={[0, -0.6, 0]} receiveShadow>
        <cylinderGeometry args={[4, 5, 1.2, 32]} />
        <meshStandardMaterial color="#5a7d3a" />
      </mesh>

      {/* Tan Malaka: 3/4 view, looking at the horizon */}
      <Character position={[0, 0, 0]} rotationY={Math.PI - 0.6} scale={1} squash={1 + Math.sin(f * 0.08) * 0.008} />

      {/* flag */}
      <group position={[1.9, 0, -0.8]}>
        <mesh position={[0, 2, 0]}><cylinderGeometry args={[0.04, 0.04, 4, 8]} /><meshStandardMaterial color="#ddd" /></mesh>
        <group position={[0, 3.6, 0]} rotation={[0, Math.sin(f * 0.15) * 0.25, 0]}>
          <mesh position={[0.5, 0.15, 0]}><boxGeometry args={[1, 0.3, 0.02]} /><meshStandardMaterial color="#e63946" /></mesh>
          <mesh position={[0.5, -0.15, 0]}><boxGeometry args={[1, 0.3, 0.02]} /><meshStandardMaterial color="#ffffff" /></mesh>
        </group>
      </group>
    </>
  );
};
