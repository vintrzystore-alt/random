import React from 'react';
import {useCurrentFrame} from 'remotion';
import {Character} from '../components/Character';
import {IndonesiaMap} from '../components/IndonesiaMap';
import {ForceRipple} from '../components/ForceRipple';
import {Burst} from '../components/Burst';
import {CamKey, SceneCamera} from '../components/SceneCamera';
import {HOOK_IMPACT} from '../config';
import {easeInOutCubic, easeOutBack, easeOutCubic, lerp, prog, V3} from '../util';

const JAKARTA: [number, number] = [-3.0, 3.9];

const KEYS: CamKey[] = [
  {f: 0, pos: [-1, 2, 9.5], look: [-3, 4, 3.9]},
  {f: 32, pos: [-1.2, 1.6, 8.4], look: [-3, 1.3, 3.9]},
  {f: 60, pos: [-0.5, 2.4, 8.8], look: [-3, 1.5, 3.9]},
  {f: 100, pos: [2, 6, 12], look: [-1, 0, 0.5]},
  {f: 150, pos: [0, 15, 12], look: [-1, 0, -1.5]},
];

/** Floating symbol for one pillar of Madilog (Materialisme / Dialektika / Logika). */
const Totem: React.FC<{f: number; start: number; position: V3; children: React.ReactNode}> = ({
  f,
  start,
  position,
  children,
}) => {
  const s = easeOutBack(prog(f, start, start + 16));
  if (s <= 0) return null;
  return (
    <group
      position={[position[0], position[1] + Math.sin(f * 0.08 + start) * 0.15, position[2]]}
      scale={s}
      rotation={[0, f * 0.04, 0]}
    >
      {children}
    </group>
  );
};

export const HookScene: React.FC = () => {
  const f = useCurrentFrame();

  // fall from the sky -> stomp
  const fall = prog(f, 0, HOOK_IMPACT);
  const y = f < HOOK_IMPACT ? lerp(9, 0, fall * fall) : 0;
  const squash = f < HOOK_IMPACT ? 1.15 : lerp(0.6, 1, easeOutBack(prog(f, HOOK_IMPACT, HOOK_IMPACT + 16)));
  // turn away from camera and walk across the map
  const rotY = lerp(0, Math.PI, easeInOutCubic(prog(f, 56, 80)));
  const walking = f > 80;
  const z = JAKARTA[1] - (walking ? (f - 80) * 0.02 : 0);

  const radius = 13 * easeOutCubic(prog(f, HOOK_IMPACT, 115));
  const rippleOpacity = 0.9 * (1 - prog(f, 70, 118));
  const flash = f >= HOOK_IMPACT ? 80 * (1 - prog(f, HOOK_IMPACT, 70)) : 0;

  return (
    <>
      <color attach="background" args={['#8fd8ff']} />
      <fog attach="fog" args={['#8fd8ff', 30, 90]} />
      <SceneCamera keys={KEYS} shakes={[{f: HOOK_IMPACT, amp: 0.35, dur: 24}]} />

      <IndonesiaMap origin={JAKARTA} radius={radius} />
      <ForceRipple position={[JAKARTA[0], 0.45, JAKARTA[1]]} radius={radius} opacity={rippleOpacity} />
      <Burst t={f - HOOK_IMPACT} position={[JAKARTA[0], 0.35, JAKARTA[1]]} count={22} speed={5} />
      <pointLight position={[JAKARTA[0], 2, JAKARTA[1]]} color="#ff2a2a" intensity={flash} distance={16} />

      <Character
        position={[JAKARTA[0], 0.3 + y, z]}
        rotationY={rotY}
        scale={0.75}
        squash={squash}
        walk={walking ? (f - 80) * 0.6 : 0}
      />

      {/* Madilog totems: Materialisme (cube), Dialektika (knot), Logika (octahedron) */}
      <Totem f={f} start={96} position={[-1.5, 3.6, 2.5]}>
        <mesh castShadow>
          <boxGeometry args={[1.1, 1.1, 1.1]} />
          <meshStandardMaterial color="#d7263d" emissive="#d7263d" emissiveIntensity={0.4} />
        </mesh>
      </Totem>
      <Totem f={f} start={108} position={[-1.5, 3.8, -0.5]}>
        <mesh castShadow>
          <torusKnotGeometry args={[0.5, 0.16, 96, 12]} />
          <meshStandardMaterial color="#ffc233" emissive="#ffb000" emissiveIntensity={0.4} />
        </mesh>
      </Totem>
      <Totem f={f} start={120} position={[-1.5, 3.6, -3.5]}>
        <mesh castShadow>
          <octahedronGeometry args={[0.75]} />
          <meshStandardMaterial color="#5ce1ff" emissive="#22bbee" emissiveIntensity={0.4} />
        </mesh>
      </Totem>
    </>
  );
};
