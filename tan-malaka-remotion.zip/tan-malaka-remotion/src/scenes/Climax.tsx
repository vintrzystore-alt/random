import React, {useMemo} from 'react';
import {useCurrentFrame} from 'remotion';
import * as THREE from 'three';
import {ForceRipple} from '../components/ForceRipple';
import {Burst} from '../components/Burst';
import {CamKey, SceneCamera} from '../components/SceneCamera';
import {CLIMAX_SLAM} from '../config';
import {easeOutBack, lerp, prog, rand} from '../util';

const KEYS: CamKey[] = [
  {f: 0, pos: [0, 1, 10], look: [0, 10, 0]},
  {f: 60, pos: [0, 1.5, 8], look: [0, 1, 0]},
  {f: CLIMAX_SLAM, pos: [0, 1.8, 7.5], look: [0, 0.8, 0]},
  {f: 100, pos: [4, 3, 9], look: [0, 1.5, 0]},
  {f: 200, pos: [-8, 9, 18], look: [0, 2, 0]},
  {f: 300, pos: [8, 20, 26], look: [0, 0.5, -1]}, // dynamic pan-out
];

const PASTELS = ['#f4a261', '#2a9d8f', '#e9c46a', '#e76f51', '#f1faee', '#a8dadc'];
const WAVE_SPEED = 2.2; // frames of delay per world unit of distance from the slam

type B = {x: number; z: number; h: number; type: number; color: string; d: number};

const BookCover: React.FC = () => {
  const tex = useMemo(() => {
    const c = document.createElement('canvas');
    c.width = 768;
    c.height = 1024;
    const g = c.getContext('2d')!;
    const grad = g.createLinearGradient(0, 0, 0, 1024);
    grad.addColorStop(0, '#9b0f1c');
    grad.addColorStop(1, '#4a0610');
    g.fillStyle = grad;
    g.fillRect(0, 0, 768, 1024);
    g.strokeStyle = '#ffd166';
    g.lineWidth = 14;
    g.strokeRect(36, 36, 696, 952);
    g.lineWidth = 4;
    g.strokeRect(62, 62, 644, 900);
    g.fillStyle = '#ffd166';
    g.textAlign = 'center';
    g.font = '900 170px Impact, "Arial Black", sans-serif';
    g.fillText('AKSI', 384, 400);
    g.fillText('MASSA', 384, 580);
    g.font = '700 54px Impact, "Arial Black", sans-serif';
    g.fillText('TAN MALAKA', 384, 760);
    // star
    g.beginPath();
    for (let i = 0; i < 10; i++) {
      const r = i % 2 ? 40 : 95;
      const a = (Math.PI / 5) * i - Math.PI / 2;
      g.lineTo(384 + Math.cos(a) * r, 880 + Math.sin(a) * r * 0.9);
    }
    g.closePath();
    g.fill();
    const t = new THREE.CanvasTexture(c);
    t.colorSpace = THREE.SRGBColorSpace;
    t.anisotropy = 8;
    return t;
  }, []);

  return (
    <mesh castShadow>
      <boxGeometry args={[4.2, 0.7, 5.6]} />
      <meshStandardMaterial attach="material-0" color="#f3e9d2" />
      <meshStandardMaterial attach="material-1" color="#7a0c18" />
      <meshStandardMaterial attach="material-2" map={tex} emissiveMap={tex} emissive="#ffffff" emissiveIntensity={0.7} />
      <meshStandardMaterial attach="material-3" color="#4a0610" />
      <meshStandardMaterial attach="material-4" color="#f3e9d2" />
      <meshStandardMaterial attach="material-5" color="#f3e9d2" />
    </mesh>
  );
};

const Building: React.FC<{b: B; e: number}> = ({b, e}) => {
  const {h, color} = b;
  return (
    <group position={[b.x, 0, b.z]} scale={[1, Math.max(e, 0.001), 1]}>
      {b.type === 0 && (
        <>
          <mesh position={[0, h * 0.3, 0]} castShadow><boxGeometry args={[1.3, h * 0.6, 1.3]} /><meshStandardMaterial color={color} /></mesh>
          <mesh position={[0, h * 0.725, 0]} castShadow><boxGeometry args={[1.0, h * 0.25, 1.0]} /><meshStandardMaterial color={color} /></mesh>
          <mesh position={[0, h * 0.925, 0]} castShadow><boxGeometry args={[0.6, h * 0.15, 0.6]} /><meshStandardMaterial color={color} /></mesh>
          <mesh position={[0, h + 0.5, 0]}><cylinderGeometry args={[0.03, 0.08, 1.2, 8]} /><meshStandardMaterial color="#ffd166" /></mesh>
        </>
      )}
      {b.type === 1 && (
        <>
          <mesh position={[0, h * 0.3, 0]} castShadow><cylinderGeometry args={[0.7, 0.75, h * 0.6, 20]} /><meshStandardMaterial color={color} /></mesh>
          <mesh position={[0, h * 0.6, 0]} castShadow><sphereGeometry args={[0.72, 20, 12, 0, Math.PI * 2, 0, Math.PI / 2]} /><meshStandardMaterial color="#ffd166" metalness={0.3} /></mesh>
        </>
      )}
      {b.type === 2 && (
        <>
          <mesh position={[0, h * 0.5, 0]} castShadow><cylinderGeometry args={[0.2, 0.28, h, 12]} /><meshStandardMaterial color="#f1faee" /></mesh>
          <mesh position={[0, h, 0]} scale={[1.2, 0.3, 1.2]} castShadow><sphereGeometry args={[1, 20, 14]} /><meshStandardMaterial color={color} emissive={color} emissiveIntensity={0.25} /></mesh>
        </>
      )}
      {b.type === 3 && (
        <>
          <mesh position={[0, h * 0.4, 0]} castShadow><cylinderGeometry args={[0.45, 0.5, h * 0.8, 14]} /><meshStandardMaterial color={color} /></mesh>
          <mesh position={[0, h * 0.8 + 0.6, 0]} castShadow><coneGeometry args={[0.45, 1.2, 14]} /><meshStandardMaterial color="#e63946" /></mesh>
          {[0, 1, 2].map((k) => (
            <mesh key={k} position={[Math.cos((k * 2 * Math.PI) / 3) * 0.55, 0.4, Math.sin((k * 2 * Math.PI) / 3) * 0.55]} rotation={[0, -(k * 2 * Math.PI) / 3, 0]}>
              <boxGeometry args={[0.5, 0.8, 0.08]} /><meshStandardMaterial color="#e63946" />
            </mesh>
          ))}
        </>
      )}
    </group>
  );
};

export const ClimaxScene: React.FC = () => {
  const f = useCurrentFrame();
  const S = CLIMAX_SLAM;

  const buildings = useMemo<B[]>(() => {
    const out: B[] = [];
    const rings: [number, number][] = [[3.9, 6], [6.2, 9], [8.8, 12], [11.5, 15]];
    let n = 0;
    rings.forEach(([r, count], ri) => {
      for (let i = 0; i < count; i++) {
        const a = (i / count) * Math.PI * 2 + ri * 0.3;
        const x = Math.cos(a) * r;
        const z = Math.sin(a) * r;
        n++;
        if (Math.hypot(x, z + 7) < 1.9) continue; // keep space for the Monas-like tower
        out.push({x, z, h: 1.6 + rand(n * 3 + 1) * 3.4 * (1.1 - ri * 0.12), type: (n + ri) % 4, color: PASTELS[n % PASTELS.length], d: r});
      }
    });
    return out;
  }, []);

  // --- book slam ---
  const fall = prog(f, 0, S);
  const bookY = f < S ? 0.35 + 26 * (1 - fall * fall) : 0.35 + 0.35 * Math.exp(-(f - S) / 6) * Math.abs(Math.sin((f - S) * 0.35));
  const bookSquash = f < S ? 1 : lerp(0.6, 1, easeOutBack(prog(f, S, S + 16)));
  const tiltX = (1 - fall) * 0.5;
  const spinY = (1 - fall) * 1.2;

  const radius = Math.max(0, (f - S) * 0.5);
  const rippleOpacity = 1 - prog(radius, 14, 24);

  const monasE = easeOutBack(prog(f, S + 7 * WAVE_SPEED, S + 7 * WAVE_SPEED + 28));

  return (
    <>
      <color attach="background" args={['#ffd6a5']} />
      <fog attach="fog" args={['#ffd6a5', 35, 110]} />
      <SceneCamera keys={KEYS} shakes={[{f: S, amp: 0.6, dur: 30}]} />

      {/* sun */}
      <mesh position={[0, 12, -60]}>
        <circleGeometry args={[9, 48]} />
        <meshBasicMaterial color="#ffb703" toneMapped={false} />
      </mesh>

      {/* ground + ring roads */}
      <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
        <circleGeometry args={[45, 64]} />
        <meshStandardMaterial color="#f6e7c1" />
      </mesh>
      {[5.05, 7.5, 10.1].map((r, i) => (
        <mesh key={i} position={[0, 0.03, 0]} rotation={[-Math.PI / 2, 0, 0]} scale={easeOutBack(prog(f, S + r * WAVE_SPEED - 6, S + r * WAVE_SPEED + 18))}>
          <ringGeometry args={[r - 0.25, r + 0.25, 72]} />
          <meshStandardMaterial color="#3d405b" />
        </mesh>
      ))}

      {/* THE BOOK */}
      <group position={[0, bookY, 0]} rotation={[tiltX, spinY, 0]} scale={[1, bookSquash, 1]}>
        <BookCover />
        <mesh scale={1 + Math.sin(f * 0.2) * 0.04}>
          <sphereGeometry args={[4, 24, 24]} />
          <meshBasicMaterial color="#ffd166" transparent opacity={0.12} blending={THREE.AdditiveBlending} depthWrite={false} toneMapped={false} />
        </mesh>
        {f < S && (
          <mesh position={[0, 6, 0]} rotation={[Math.PI, 0, 0]}>
            <coneGeometry args={[1.8, 12, 20, 1, true]} />
            <meshBasicMaterial color="#ffe08a" transparent opacity={0.18} blending={THREE.AdditiveBlending} depthWrite={false} toneMapped={false} />
          </mesh>
        )}
      </group>
      <pointLight position={[0, 3, 0]} color="#ffd166" intensity={f >= S ? 60 + 140 * Math.max(0, 1 - (f - S) / 20) : 40} distance={30} />

      {/* shockwave + debris */}
      <ForceRipple position={[0, 0.08, 0]} radius={radius} opacity={rippleOpacity} color="#ffd166" />
      <ForceRipple position={[0, 0.07, 0]} radius={Math.max(0, radius - 2.5)} opacity={rippleOpacity} color="#ff3b30" />
      <Burst t={f - S} position={[0, 0.4, 0]} count={30} speed={9} color="#f6c177" size={0.16} life={45} />

      {/* city grows as the wave passes */}
      {buildings.map((b, i) => (
        <Building key={i} b={b} e={easeOutBack(prog(f, S + b.d * WAVE_SPEED, S + b.d * WAVE_SPEED + 26))} />
      ))}

      {/* Monas-style tower */}
      <group position={[0, 0, -7]} scale={[1, Math.max(monasE, 0.001), 1]}>
        <mesh position={[0, 0.3, 0]} castShadow><boxGeometry args={[3, 0.6, 3]} /><meshStandardMaterial color="#f1faee" /></mesh>
        <mesh position={[0, 4.8, 0]} castShadow><cylinderGeometry args={[0.15, 0.45, 8.4, 4]} /><meshStandardMaterial color="#f8f4e8" /></mesh>
        <mesh position={[0, 9.4, 0]}><sphereGeometry args={[0.5, 16, 16]} /><meshStandardMaterial color="#ffc400" emissive="#ffb000" emissiveIntensity={1} /></mesh>
      </group>

      {/* retro flying cars */}
      {f > 150 &&
        [0, 1, 2, 3, 4, 5].map((i) => {
          const a = f * 0.02 * (i % 2 ? -1 : 1) + i * 1.05;
          const r = 6 + (i % 3) * 2.2;
          return (
            <group key={i} position={[Math.cos(a) * r, 4.5 + Math.sin(f * 0.07 + i) * 0.4 + (i % 3) * 0.6, Math.sin(a) * r]} rotation={[0, -(a + Math.PI / 2) * (i % 2 ? -1 : 1), 0]}>
              <mesh rotation={[0, 0, Math.PI / 2]} castShadow>
                <capsuleGeometry args={[0.22, 0.8, 6, 12]} />
                <meshStandardMaterial color={PASTELS[i]} />
              </mesh>
              <mesh position={[-0.55, 0.22, 0]}><boxGeometry args={[0.3, 0.3, 0.05]} /><meshStandardMaterial color="#e63946" /></mesh>
              <mesh position={[0.6, 0, 0]}><sphereGeometry args={[0.1, 8, 8]} /><meshStandardMaterial color="#fff" emissive="#fff" emissiveIntensity={1} /></mesh>
            </group>
          );
        })}
    </>
  );
};
