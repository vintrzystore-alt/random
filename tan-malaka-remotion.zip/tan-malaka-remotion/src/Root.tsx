import React from 'react';
import {Composition} from 'remotion';
import {TanMalaka, MainProps} from './Main';
import {DURATION_FRAMES, FPS, HEIGHT, WIDTH} from './config';

const base = {
  component: TanMalaka,
  durationInFrames: DURATION_FRAMES,
  fps: FPS,
  width: WIDTH,
  height: HEIGHT,
};

export const RemotionRoot: React.FC = () => (
  <>
    {/* Clean master — this is the one you publish */}
    <Composition id="TanMalaka" {...base} defaultProps={{guides: 'none'} as MainProps} />
    {/* Same video with the platform-UI safe-area overlay burned in (for checking only) */}
    <Composition id="TanMalaka-SafeCheck" {...base} defaultProps={{guides: 'all'} as MainProps} />
  </>
);
