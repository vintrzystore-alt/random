import React from 'react';
import {AbsoluteFill, spring, useCurrentFrame, useVideoConfig} from 'remotion';
import {loadFont} from '@remotion/google-fonts/LilitaOne';
import {CAPTIONS, CaptionLine, WordTiming} from './captions';
import {SAFE, WIDTH} from './config';

export const {fontFamily: DISPLAY_FONT} = loadFont();

const HIGHLIGHT = /madilog|aksi|massa|rantai/i;

const timeWords = (line: CaptionLine): WordTiming[] => {
  if (line.words) return line.words;
  const ws = line.text.split(' ');
  const total = ws.reduce((a, w) => a + w.length + 1, 0);
  let acc = 0;
  return ws.map((w) => {
    const start = line.start + (acc / total) * (line.end - line.start);
    acc += w.length + 1;
    const end = line.start + (acc / total) * (line.end - line.start);
    return {text: w, start, end};
  });
};

export const Captions: React.FC = () => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const t = frame / fps;

  const line = CAPTIONS.find((l) => t >= l.start - 0.05 && t < l.end + 0.3);
  if (!line) return null;

  const words = timeWords(line);
  const pop = spring({
    frame: frame - Math.round(line.start * fps),
    fps,
    config: {damping: 12, stiffness: 200},
  });

  return (
    <AbsoluteFill style={{pointerEvents: 'none'}}>
      <div
        style={{
          position: 'absolute',
          left: SAFE.left,
          width: WIDTH - SAFE.left - SAFE.right,
          bottom: SAFE.bottom + 60,
          textAlign: 'center',
          transform: `scale(${0.85 + 0.15 * Math.min(pop, 1.15)})`,
          transformOrigin: '50% 100%',
        }}
      >
        {words.map((w, i) => {
          const active = t >= w.start && t < w.end;
          const spoken = t >= w.end;
          const hl = HIGHLIGHT.test(w.text);
          return (
            <span
              key={i}
              style={{
                display: 'inline-block',
                margin: '0 12px',
                fontFamily: DISPLAY_FONT,
                fontSize: 78,
                lineHeight: 1.15,
                textTransform: 'uppercase',
                color: active ? (hl ? '#ff4d4d' : '#ffe600') : '#ffffff',
                opacity: active || spoken ? 1 : 0.72,
                transform: active ? 'scale(1.18) translateY(-6px)' : 'scale(1)',
                WebkitTextStroke: '12px #000',
                paintOrder: 'stroke fill',
                textShadow: '0 8px 0 rgba(0,0,0,0.45)',
              }}
            >
              {w.text}
            </span>
          );
        })}
      </div>
    </AbsoluteFill>
  );
};
