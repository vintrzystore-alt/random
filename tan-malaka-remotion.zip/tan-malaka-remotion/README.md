# Bagaimana jika Indonesia dipimpin Tan Malaka? — Remotion + React Three Fiber (9:16)

1080x1920 @ 30fps, 35 s (1050 frames). All 3D assets are primitive-shape proxies.

## Run
Requires Node 18+.

    npm install
    npm run dev            # Remotion Studio: scrub the timeline, pick TanMalaka or TanMalaka-SafeCheck

## Render to MP4
    npm run render         # clean master  -> out/tan-malaka.mp4
    npm run render:check   # with safe-area overlay burned in -> out/tan-malaka-safecheck.mp4
    # WebGL is heavy; if it stalls or runs out of memory:
    npx remotion render src/index.ts TanMalaka out/tan-malaka.mp4 --concurrency=2

## Voiceover + captions
1. Record/generate Indonesian voiceover, save as public/voiceover.mp3
2. Set HAS_VOICEOVER = true in src/config.ts
3. Edit src/captions.ts: start/end (seconds) per line. For exact karaoke timing give a line
   its own `words: [{text,start,end}]` (e.g. from a Whisper transcription). Otherwise words
   are spread by character length.

## Timeline (global seconds)
| Scene  | Time    | File                | Key beats |
|--------|---------|---------------------|-----------|
| Hook   | 0–5     | scenes/Hook.tsx     | fall + stomp @1.07s, red ripple converts the map, Madilog totems |
| Body   | 5–20    | scenes/Body.tsx     | factory/fields rise, crowd unites, slow-mo 5x from 16s, chains snap @17.67s |
| Climax | 20–30   | scenes/Climax.tsx   | book slam @22.33s, shockwave builds city, pan-out |
| Outro  | 30–35   | scenes/Outro.tsx    | slow zoom on Tan Malaka at sunset horizon |

## Swap in GLTF models later
Put files in public/models/, then replace the body of `components/Character.tsx`:

    import {useLoader} from '@react-three/fiber';
    import {GLTFLoader} from 'three/examples/jsm/loaders/GLTFLoader.js';
    import {continueRender, delayRender, staticFile} from 'remotion';
    import {Suspense, useEffect, useState} from 'react';

    const Hold = () => {
      const [h] = useState(() => delayRender('gltf'));
      useEffect(() => () => continueRender(h), [h]);
      return null;
    };
    const Model = () => {
      const gltf = useLoader(GLTFLoader, staticFile('models/tan.glb'));
      return <primitive object={gltf.scene} />;
    };
    // <Suspense fallback={<Hold />}><Model /></Suspense>

## Tuning notes
- Safe area (src/config.ts SAFE) is a conservative estimate; platform UI changes, so verify.
- Light intensities assume three r155+ physical lights; adjust in components/Lights.tsx.
- Cartoon outlines (inverted-hull) and toon materials are good next upgrades.
- The video is speculative alternate history; the on-screen disclaimer is in src/Titles.tsx.
