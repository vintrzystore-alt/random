import {Config} from '@remotion/cli/config';

Config.setVideoImageFormat('jpeg');
Config.setOverwriteOutput(true);
// WebGL in headless Chrome: ANGLE is the most reliable on Win/Mac/Linux.
Config.setChromiumOpenGlRenderer('angle');
